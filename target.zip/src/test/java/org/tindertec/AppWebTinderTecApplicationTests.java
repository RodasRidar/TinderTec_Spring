package org.tindertec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppWebTinderTecApplicationTests {

	@Test
	void contextLoads() {
	}

}
